from django.apps import AppConfig

class GeoPositionConfig(AppConfig):
    name = 'geoposition'
    verbose_name = "GeoPosition"
